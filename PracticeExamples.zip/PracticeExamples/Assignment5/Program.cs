﻿namespace Assignment5
{
    internal class Program
    {
        static void Main(string[] args)
        {            
            Console.WriteLine("Enter the character for which you want ASCII Value to be printed -");
            var newChar = (int)Console.Read();
            Console.WriteLine("The ASCII value is : " + newChar);
            Console.ReadKey();

        }
    }
}
