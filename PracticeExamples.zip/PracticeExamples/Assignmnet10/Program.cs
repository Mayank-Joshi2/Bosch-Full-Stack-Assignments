﻿namespace Assignmnet10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3,max;

            Console.WriteLine("Enter number1 :");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number2 :");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number3 :");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                max = num1;
            }
            else if (num2 > num1 && num2 > num3)
            {

                max = num2;
            }

            else
            {
                max = num3;
            }

            Console.WriteLine("Max number is :" + max);
        }
    }
}
