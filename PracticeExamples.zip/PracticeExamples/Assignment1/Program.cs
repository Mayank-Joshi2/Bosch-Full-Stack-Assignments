﻿namespace Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int sum, num1, num2, num3, num4, num5;
                Console.WriteLine("Please enter the marks of 5 subjects -");
                num1 = Convert.ToInt32(Console.ReadLine());
                num2 = Convert.ToInt32(Console.ReadLine());
                num3 = Convert.ToInt32(Console.ReadLine());
                num4 = Convert.ToInt32(Console.ReadLine());
                num5 = Convert.ToInt32(Console.ReadLine());

                sum = num1 + num2 + num3 + num4 + num5;

                Console.WriteLine("The Sum of the provided marks is : " + sum);
            }
            catch (Exception ex) {
                Console.WriteLine(ex);
            }
        }
    }
}
