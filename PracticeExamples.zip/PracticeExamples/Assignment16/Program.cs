﻿namespace Assignment16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char pattern = '*';

            Console.WriteLine("Enter max number of stars in star pattern");

            int maxStars = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i <= maxStars; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    Console.Write(pattern +" ");
                }
                Console.WriteLine("\n");
            }

            Console.ReadKey();
        }
    }
}
