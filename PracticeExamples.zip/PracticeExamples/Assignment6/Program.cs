﻿namespace Assignment6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int basicSalary, HRA, DA, PF, grossSalary, netSalary;
            Console.WriteLine("Enter Basic Salary -");
            basicSalary = Convert.ToInt32(Console.ReadLine());
            HRA = (basicSalary * 20 )/ 100;
            DA = (basicSalary * 40) / 100;
            grossSalary = basicSalary + HRA + DA;
            PF = (grossSalary * 10) / 100;
            netSalary = grossSalary - PF;
            Console.WriteLine("The Net Salary of the employee is : " + netSalary);

        }
    }
}
