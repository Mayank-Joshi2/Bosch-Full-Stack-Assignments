﻿namespace Assignment8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int basicSalary, sales, commission, netSalary;

            Console.WriteLine("Enter the Basic Salary - ");
            basicSalary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Sales - ");
            sales = Convert.ToInt32(Console.ReadLine());

            if (sales >= 5000 & sales <= 7500)
            {
                commission = (sales * 3) / 100;
            }
            else if (sales >= 7501 & sales <= 10500)
            {
                commission = (sales * 8) / 100;
            }
            else if (sales >= 10501 & sales <= 15000)
            {
                commission = (sales * 11) / 100;
            }
            else if (sales > 15001)
            {
                commission = (sales * 15) / 100;
            }
            else
            {
                commission = 0;
            }

            netSalary = basicSalary + commission;

            Console.WriteLine("Net Salary = "+ netSalary);
            Console.WriteLine("Commission = " + commission);
        }
    }
}
