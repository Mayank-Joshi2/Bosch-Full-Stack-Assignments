﻿namespace Assignment4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = 30, num2 =25;
            int num3;

            Console.WriteLine("The current num1 & num 2 are : num1 = "+ num1 + " num2 = "+num2);

            num3 = num1;
            num1 = num2;
            num2 = num3;

            Console.WriteLine("The current num1 & num 2 are : num1 = " + num1 + " num2 = " + num2);
            Console.ReadKey();
        }
    }
}
