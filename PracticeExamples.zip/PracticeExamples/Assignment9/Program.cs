﻿using System.Linq.Expressions;

namespace Assignment9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.WriteLine("Enter number1 :");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number2 :");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your choice of operation out of the following: Addition, Substraction, Multiplication or Division :");
            string expression = Console.ReadLine().ToUpper();

            switch (expression)
            {
                case "ADDITION":
                    Console.WriteLine("The addition of the numbers is : "+ (num1 + num2));
                    break;
                case "SUBSTRACTION":
                    Console.WriteLine("The addition of the numbers is : " + (num1 - num2));
                    break;
                case "MULTIPLICATION":
                    Console.WriteLine("The addition of the numbers is : " + (num1 * num2));
                    break;
                case "DIVISION":
                    Console.WriteLine("The addition of the numbers is : " + (num1 / num2));
                    break;
                default:
                    Console.WriteLine("No such operation available");
                    break;
            }
        }
    }
}
