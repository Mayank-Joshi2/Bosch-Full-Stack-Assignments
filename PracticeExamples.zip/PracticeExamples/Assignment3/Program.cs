﻿namespace Assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = 20;
            int num2 = 50;
            int sum = num1 + num2;
            Console.WriteLine("Sum of num1 & num2 is :"+sum);
            Console.ReadKey();
        }
    }
}
