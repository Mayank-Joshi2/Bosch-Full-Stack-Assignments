﻿using Bosch.Events.Domain.Entities;

namespace Bosch.Events.Layered.API.Jwt
{
    public interface ITokenManager
    {
        string GenerateToken(User user, string roleName);
    }
}
