﻿using AutoMapper;
using Bosch.Events.Domain.Entities;
using Bosch.Events.UseCases.Contracts;
using Bosch.Events.UseCases.DTOs.RoleDtos;
using Microsoft.AspNetCore.Mvc;

namespace Bosch.Events.Layered.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BoschRolesController : ControllerBase
    {
        private readonly ICommonRepository<Role> _roleRepository;
        private readonly IMapper _mapper;

        public BoschRolesController(ICommonRepository<Role> roleRepository, IMapper mapper)
        {
            _roleRepository = roleRepository;
            _mapper = mapper;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<List<RoleDto>>> Get()
        {
            try
            {
                var roles = _mapper.Map<List<RoleDto>>(await _roleRepository.GetAllAsync());
                if (roles.Count <= 0)
                {
                    return NotFound(new { message = "No roles found!" });
                }
                return Ok(roles);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<RoleDto>> Get(int id)
        {
            try
            {
                var role = _mapper.Map<RoleDto>(await _roleRepository.GetDetailsAsync(id));
                if (role == null)
                {
                    return NotFound(new { message = "No role found!" });
                }
                return Ok(role);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Post(InsertRoleDto role)
        {
            if (ModelState.IsValid)
            {
                int result = await _roleRepository.InsertAsync(_mapper.Map<Role>(role));

                if (result > 0)
                {
                    return Created("GetDetails", role);
                }
            }
            return BadRequest(new { message = "Role Creation Failed! Please retry!" });
        }

        [HttpPut]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Put(int RoleId, InsertRoleDto Role)
        {
            if (ModelState.IsValid)
            {
                Role updateRole = _mapper.Map<Role>(Role);
                updateRole.RoleId = RoleId;
                int result = await _roleRepository.UpdateAsync(updateRole);

                if (result > 0)
                {
                    return Created("GetDetails", Role);
                }
            }
            return BadRequest(new { message = "Role Updation Failed! Please retry!" });
        }

        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Delete(int RoleId)
        {
            int result = await _roleRepository.DeleteAsync(RoleId);

            if (result > 0)
            {
                return Ok(new { message = "Role record deleted successfully!" });
            }
            return BadRequest(new { message = "Role record deletion Failed! Please retry!" });
        }
    }
}
