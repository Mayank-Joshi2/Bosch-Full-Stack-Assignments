﻿using AutoMapper;
using Bosch.Events.Domain.Entities;
using Bosch.Events.Layered.API.Jwt;
using Bosch.Events.UseCases;
using Bosch.Events.UseCases.Contracts;
using Bosch.Events.UseCases.DTOs.UserDtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace Bosch.Events.Layered.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles ="Admin")]
    [EnableCors]
    public class BoschUserController : ControllerBase
    {
        private readonly ICommonRepository<User> _userRepository;
        private readonly ICommonRepository<Role> _roleRepository;
        private readonly IBoschAuthenticator _boschAuthenticator;
        private readonly ITokenManager _tokenManager;
        private readonly IMapper _mapper;

        public BoschUserController(ICommonRepository<User> UserRepository, IMapper mapper, IBoschAuthenticator boschAuthenticator, ICommonRepository<Role> roleRepository, ITokenManager tokenManager)
        {
            _userRepository = UserRepository;
            _boschAuthenticator = boschAuthenticator;
            _roleRepository = roleRepository;
            _tokenManager = tokenManager;
            _mapper = mapper;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<List<UserDto>>> Get()
        {
            try
            {
                var Users = _mapper.Map<List<UserDto>>(await _userRepository.GetAllAsync());
                if (Users.Count <= 0)
                {
                    return NotFound(new { message = "No Users found!" });
                }
                return Ok(Users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<UserDto>> Get(int id)
        {
            try
            {
                var User = _mapper.Map<UserDto>(await _userRepository.GetDetailsAsync(id));
                if (User == null)
                {
                    return NotFound(new { message = "No User found!" });
                }
                return Ok(User);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Post(InsertUserDto User)
        {
            var hashedPassword = BCrypt.Net.BCrypt.HashPassword(User.Password);
            User.Password = hashedPassword;
            if (ModelState.IsValid)
            {
                int result = await _userRepository.InsertAsync(_mapper.Map<User>(User));

                if (result > 0)
                {
                    return Created("GetDetails", User);
                }
            }
            return BadRequest(new { message = "User Creation Failed! Please retry!" });
        }

        [HttpPost("Credentials")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<UserDto>> CheckCredentialsPost(UserDto User)
        {
            if (ModelState.IsValid)
            {
                var result = await _boschAuthenticator.Authenticate(_mapper.Map<User>(User));

                if (result!= null)
                {
                    var passwordVerification = BCrypt.Net.BCrypt.Verify(User.Password, result.Password);
                    if(!passwordVerification)
                    {
                        return BadRequest(new { message="Please check your password!!" });
                    }
                    var role = await _roleRepository.GetDetailsAsync(result.RoleId);
                    return Ok(new AuthResponse() { Email = result.UserName, Role = role.RoleName , Success = true, token = _tokenManager.GenerateToken(result, role.RoleName)});
                }
                else
                {
                    return BadRequest(new { message = $"User with Email/Name:{User.UserName} doesn't exist!!" });
                }
            }
            return BadRequest(new { message = "Please check Input" });
        }

        [HttpPut]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Put(int userId,InsertUserDto User)
        {
            if (ModelState.IsValid)
            {
                User updateUser = _mapper.Map<User>(User);
                updateUser.UserId = userId;
                int result = await _userRepository.UpdateAsync(updateUser);

                if (result > 0)
                {
                    return Created("GetDetails", User);
                }
            }
            return BadRequest(new { message = "User Updation Failed! Please retry!" });
        }

        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Delete(int userId)
        {
          int result = await _userRepository.DeleteAsync(userId);

          if (result > 0)
          {
              return Ok(new { message = "User record deleted successfully!" });
          }
            return BadRequest(new { message = "User record deletion Failed! Please retry!" });
        }
    }
}
