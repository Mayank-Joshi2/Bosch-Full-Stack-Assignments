﻿using AutoMapper;
using Bosch.Events.Domain.Entities;
using Bosch.Events.UseCases.Contracts;
using Bosch.Events.UseCases.DTOs.EventDtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace Bosch.Events.Layered.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "HR")]
    [EnableCors]
    public class BoschEventsController : ControllerBase
    {
        private readonly ICommonRepository<Event> _eventRepository;
        private readonly IMapper _mapper;

        public BoschEventsController(ICommonRepository<Event> eventRepository, IMapper mapper)
        {
            _eventRepository = eventRepository;
            _mapper = mapper;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<List<EventDto>>> Get()
        {
            try
            {
                var Events = _mapper.Map<List<EventDto>>(await _eventRepository.GetAllAsync());
                if (Events.Count <= 0)
                {
                    return NotFound(new { message = "No Events found!" });
                }
                return Ok(Events);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<EventDto>> Get(int id)
        {
            try
            {
                var Event = _mapper.Map<EventDto>(await _eventRepository.GetDetailsAsync(id));
                if (Event == null)
                {
                    return NotFound(new { message = "No Event found!" });
                }
                return Ok(Event);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Post(InsertEventDto Event)
        {
            if (ModelState.IsValid)
            {
                int result = await _eventRepository.InsertAsync(_mapper.Map<Event>(Event));

                if (result > 0)
                {
                    return Created("GetDetails", Event);
                }
            }
            return BadRequest(new { message = "Event Creation Failed! Please retry!" });
        }

        [HttpPut]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Put(int EventId, InsertEventDto Event)
        {
            if (ModelState.IsValid)
            {
                Event updateEvent = _mapper.Map<Event>(Event);
                updateEvent.EventId = EventId;
                int result = await _eventRepository.UpdateAsync(updateEvent);

                if (result > 0)
                {
                    return Created("GetDetails", Event);
                }
            }
            return BadRequest(new { message = "Event Updation Failed! Please retry!" });
        }

        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> Delete(int EventId)
        {
            int result = await _eventRepository.DeleteAsync(EventId);

            if (result > 0)
            {
                return Ok(new { message = "Event record deleted successfully!" });
            }
            return BadRequest(new { message = "Event record deletion Failed! Please retry!" });
        }
    }
}
