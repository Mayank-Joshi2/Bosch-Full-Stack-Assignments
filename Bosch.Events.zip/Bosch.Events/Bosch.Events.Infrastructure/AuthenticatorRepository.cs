﻿using Bosch.Events.DAL;
using Bosch.Events.Domain.Entities;
using Bosch.Events.UseCases;
using Microsoft.EntityFrameworkCore;

namespace Bosch.Events.Infrastructure
{
    public class AuthenticatorRepository : IBoschAuthenticator
    {
        private readonly BoschEventsDBContext _dbContext;
        public AuthenticatorRepository(BoschEventsDBContext dBContext) 
        {
            _dbContext = dBContext;
        }

        public async Task<User> Authenticate(User userInput)
        {
            return await _dbContext.Users.SingleOrDefaultAsync(user => user.UserName == userInput.UserName);
        }
    }
}
