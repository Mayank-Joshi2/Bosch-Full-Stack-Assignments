﻿namespace Bosch.Events.UseCases.DTOs.RoleDtos
{
    public class RoleDto
    {
        public int RoleId { get; set; }
        public string? RoleName { get; set; }
        public string? RoleDescription { get; set; }
    }
}
