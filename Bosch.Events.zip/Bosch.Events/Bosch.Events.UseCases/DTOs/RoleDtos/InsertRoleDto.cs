﻿namespace Bosch.Events.UseCases.DTOs.RoleDtos
{
    public class InsertRoleDto
    {
        public string? RoleName { get; set; }
        public string? RoleDescription { get; set; }
    }
}
