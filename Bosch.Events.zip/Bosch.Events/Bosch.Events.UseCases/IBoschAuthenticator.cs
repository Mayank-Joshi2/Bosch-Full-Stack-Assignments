﻿using Bosch.Events.Domain.Entities;

namespace Bosch.Events.UseCases
{
    public interface IBoschAuthenticator
    {
        Task<User> Authenticate(User user);
    }
}
