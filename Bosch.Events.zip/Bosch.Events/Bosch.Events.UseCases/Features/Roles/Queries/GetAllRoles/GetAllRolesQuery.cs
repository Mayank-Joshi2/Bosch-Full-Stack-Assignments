﻿using Bosch.Events.UseCases.DTOs.RoleDtos;
using MediatR;

namespace Bosch.Events.UseCases.Features.Roles.Queries.GetAllRoles
{
    //Query - Requirement
    //Query - Requesting to get all roles/ list of all roles
    public class GetAllRolesQuery:IRequest<List<RoleDto>>
    {
    }
}
