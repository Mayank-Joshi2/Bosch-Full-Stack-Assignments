﻿using AutoMapper;
using Bosch.Events.Domain.Entities;
using Bosch.Events.UseCases.Contracts;
using Bosch.Events.UseCases.DTOs.RoleDtos;
using MediatR;

namespace Bosch.Events.UseCases.Features.Roles.Queries.GetAllRoles
{
    //Handler for requirement
    public class GetAllRolesQueryHandler : IRequestHandler<GetAllRolesQuery, List<RoleDto>>
    {
        private readonly ICommonRepository<Role> _rolesRepostory;
        private readonly IMapper _mapper;

        public GetAllRolesQueryHandler(ICommonRepository<Role> rolesRepository, IMapper mapper)
        {
            _rolesRepostory = rolesRepository;
            _mapper = mapper;
        }

        public async Task<List<RoleDto>> Handle(GetAllRolesQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<RoleDto>>(await _rolesRepostory.GetAllAsync());
        }

    }
}
