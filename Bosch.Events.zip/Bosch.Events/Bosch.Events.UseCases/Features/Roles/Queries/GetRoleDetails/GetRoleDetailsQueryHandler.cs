﻿using AutoMapper;
using Bosch.Events.Domain.Entities;
using Bosch.Events.UseCases.Contracts;
using Bosch.Events.UseCases.DTOs.RoleDtos;
using MediatR;

namespace Bosch.Events.UseCases.Features.Roles.Queries.GetRoleDetails
{
    public class GetRoleDetailsQueryHandler : IRequestHandler<GetRoleDetailsQuery, RoleDto>
    {
        private readonly ICommonRepository<Role> _rolesRepostory;
        private readonly IMapper _mapper;

        public GetRoleDetailsQueryHandler(ICommonRepository<Role> rolesRepository, IMapper mapper)
        {
            _rolesRepostory = rolesRepository;
            _mapper = mapper;
        }

        public async Task<RoleDto> Handle(GetRoleDetailsQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<RoleDto>(await _rolesRepostory.GetDetailsAsync(request.RoleID));
        }
    }
}
