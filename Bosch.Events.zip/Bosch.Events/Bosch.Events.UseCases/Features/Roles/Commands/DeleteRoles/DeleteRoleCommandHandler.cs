﻿namespace Bosch.Events.UseCases.Features.Roles.Commands.DeleteRoles
{
    public class DeleteRoleCommandHandler
    {
    }
}
