﻿namespace Bosch.Events.UseCases.Features.Roles.Commands.UpdateRoles
{
    public class UpdateRoleCommandHandler
    {
    }
}
