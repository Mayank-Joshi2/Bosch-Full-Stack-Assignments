﻿using Bosch.Calculator;
using System.Linq.Expressions;

namespace BoschCaluclator
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Please Enter Menu Item Number From Below Menu-" +
                "\n 1- Addition" +
                "\n 2- Substraction" +
                "\n 3- Multiply" +
                "\n 4- Divide" +
                "\n 5- Square" +
                "\n 6- Square Root");

            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    {
                        Console.WriteLine("Enter first number for addition -");
                        double a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Second number for addition -");
                        double b = Convert.ToInt32(Console.ReadLine());
                        double addition = BasicMath.Add(a, b);
                        Console.WriteLine("Addition of numbers is - "+addition);
                    }
                    break;
                case 2:
                    {
                        Console.WriteLine("Enter first number for substraction -");
                        double a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Second number for substraction -");
                        double b = Convert.ToInt32(Console.ReadLine());
                        double substraction = BasicMath.Substract(a, b);
                        Console.WriteLine("Substraction of numbers is - " + substraction);
                    }
                    break;
                case 3:
                    {
                        Console.WriteLine("Enter first number for multiplication -");
                        double a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Second number for multiplication -");
                        double b = Convert.ToInt32(Console.ReadLine());
                        double multiply = BasicMath.Multiply(a, b);
                        Console.WriteLine("Multiplication of numbers is - " + multiply);
                    }
                    break;
                case 4:
                    {
                        Console.WriteLine("Enter first number for division -");
                        double a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Second number for division -");
                        double b = Convert.ToInt32(Console.ReadLine());
                        double divide = BasicMath.Divide(a, b);
                        Console.WriteLine("Division of numbers is - " + divide);
                    }
                    break;
                case 5:
                    {
                        Console.WriteLine("Enter number for Squaring -");
                        double a = Convert.ToInt32(Console.ReadLine());
                        double square = AdvanceMath.Square(a);
                        Console.WriteLine("Square of numbers is - " + square);
                    }
                    break;
                case 6:
                    {
                        Console.WriteLine("Enter number for Squaring -");
                        double a = Convert.ToInt32(Console.ReadLine());
                        double squareroot = AdvanceMath.SquareRoot(a);
                        Console.WriteLine("Square of numbers is - " + squareroot);
                    }
                    break;
                default:
                    Console.WriteLine("Please make a valid chocie for Item Number between 1 - 6");
                    break;
            }
        }
    }
}
