﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bosch.Calculator
{
    public class AdvanceMath : BasicMath
    {
        public static double SquareRoot(double a) 
        {
            return Math.Sqrt(a);
        }

        public static double Square(double a)
        {
            return a * a;
        }
    }
}
