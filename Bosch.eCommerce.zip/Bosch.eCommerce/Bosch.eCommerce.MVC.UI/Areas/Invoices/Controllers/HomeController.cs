﻿using Bosch.eCommerce.Models;
using Bosch.eCommerce.Persistance;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Razorpay.Api;
using Invoice = Bosch.eCommerce.Models.Invoice;
using Customer = Bosch.eCommerce.Models.Customer;
using AutoMapper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;

namespace Bosch.eCommerce.MVC.UI.Areas.Invoices.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICommonRepository<Customer> _customerRepository;
        public HomeController(ICommonRepository<Customer> customerRepository)
        {
            _customerRepository = customerRepository;
        }

        [Area("Invoices")]
        public async Task<IActionResult> Index(int customerid)
        {
            Customer customer = new Customer();
            customer = await _customerRepository.GetDetailsAsync(customerid);
            TempData["TotalAmountPayable"] = JsonConvert.SerializeObject((decimal)HttpContext.Session.Get<decimal>("TotalAmountPayable"));
            return View(customer);
        }

        [Area("Invoices")]
        public async Task<IActionResult> InitiateOrder()
        {
            var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            TempData["keyID"] = builder.GetSection("RazorPayAuth")["KeyID"];
            string KeySecret = builder.GetSection("RazorPayAuth")["KeySecret"];

            TempData["TotalAmountPayable"] = (decimal)HttpContext.Session.Get <decimal>("TotalAmountPayable");
            Customer customer = await _customerRepository.GetDetailsAsync((int)HttpContext.Session.GetInt32("CustomerId"));

            Random _random = new Random();
            string TransactionID = _random.Next(0,1000).ToString();
            TempData["InvoiceID"] = Convert.ToInt32(TransactionID);

            Dictionary<string, object> input = new Dictionary<string, object>();
            input.Add("amount", Convert.ToInt32(TempData["TotalAmountPayable"]) * 100); // this amount should be same as transaction amount
            input.Add("currency", "INR");
            input.Add("receipt", TransactionID);            

            RazorpayClient client = new RazorpayClient(TempData["keyID"].ToString(), KeySecret);
            Razorpay.Api.Order order = client.Order.Create(input);
            ViewBag.orderId = order["id"].ToString();

            return View("Payment", customer);
        }

        [Area("Invoices")]
        public IActionResult Payment(string razorpay_payment_id, string razorpay_order_id, string razorpay_signature)
        {
            Dictionary<string,string> attributes = new Dictionary<string, string>();
            attributes.Add("razorpay_payment_id", razorpay_payment_id);
            attributes.Add("razorpay_order_id", razorpay_order_id);
            attributes.Add("razorpay_signature", razorpay_signature);

            if (!razorpay_signature.IsNullOrEmpty())
            {
                Utils.verifyPaymentSignature(attributes);
                Invoice invoice = new Invoice();
                invoice.InvoiceDate = DateTime.Now;
                invoice.InvoiceId = Convert.ToInt32(TempData["InvoiceID"]);
                return View("PaymentSuccess", invoice);
            }
            else
                return View("PaymentFailure");


        }
    }
}
