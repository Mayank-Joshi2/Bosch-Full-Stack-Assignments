﻿using Microsoft.AspNetCore.Mvc;
using Bosch.eCommerce.Models;
using Newtonsoft.Json;
using Bosch.eCommerce.Persistance;
using AutoMapper;
using Bosch.eCommerce.Models.DTOs.CartItemDtos;
using Microsoft.AspNetCore.Http;

namespace Bosch.eCommerce.MVC.UI.Areas.Carts.Controllers
{
    [Area("Carts")]
    public class HomeController : Controller
    {
        private readonly ICommonRepository<CartItem> _cartItemRepository;
        private readonly IGenerateCart _generateCart;
        private readonly IMapper _mapper;

        public HomeController(ICommonRepository<CartItem> cartItemRepository, IGenerateCart generateCart, IMapper mapper)
        {
            _cartItemRepository = cartItemRepository;
            _generateCart = generateCart;
            _mapper = mapper;
        }

        public async Task<IActionResult> YourCartItems()
        {
            decimal totalPrice = 0;
            if (HttpContext.Session.GetInt32("CartId") == null)
            {
                ViewBag.NoItemsInCartMessage = "Your Cart is Empty";
                return View();
            }
            var cartDetailsData = await _generateCart.GetCartItems((int)HttpContext.Session.GetInt32("CartId"));
            if (cartDetailsData.Count <= 0)
            {
                ViewBag.NoItemsInCartMessage = "Your Cart is Empty";
            }

            foreach (var cartItem in cartDetailsData)
            {
                totalPrice = totalPrice + Convert.ToDecimal(cartItem.DiscountedAmount);
            }

            TempData["CustomerId"] = (int)HttpContext.Session.GetInt32("CustomerId");
            HttpContext.Session.Set<decimal>("TotalAmountPayable", totalPrice);
            TempData["TotalAmountPayable"] = totalPrice;            
            return View(cartDetailsData);
        }

        [Area("Carts")]
        public async Task<IActionResult> AddToCart(int productId)
        {
            HttpContext.Session.SetInt32("CustomerId", 1);
            if (HttpContext.Session.GetInt32("CartId") == null)
            {
                int cartId = await _generateCart.GenerateNewCart((int)HttpContext.Session.GetInt32("CustomerId"));
                HttpContext.Session.SetInt32("CartId", cartId);
            }
            var cartItemDto = new InsertCartItemDto()
            {
                CartId = (int)HttpContext.Session.GetInt32("CartId"),
                ProductId = productId,
            };
            var cartItem = _mapper.Map<CartItem>(cartItemDto);
            int result = await _cartItemRepository.InsertAsync(cartItem);
            if (result > 0)
            {
                return RedirectToAction("YourCartItems");
            }

            return RedirectToAction("AddToCart");
        }
    }
}
