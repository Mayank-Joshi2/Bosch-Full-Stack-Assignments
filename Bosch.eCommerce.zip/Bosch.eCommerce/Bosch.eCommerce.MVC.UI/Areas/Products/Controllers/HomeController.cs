﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerce.MVC.UI.DTOs.ProductDtos;
using Bosch.eCommerce.Persistance;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using System.Drawing;

namespace Bosch.eCommerce.MVC.UI.Areas.Products.Controllers
{
    [Area("Products")]
    public class HomeController : Controller
    {
        private readonly ICommonRepository<Product>_productRepository;
        private readonly ICommonRepository<Category> _categoryRepository;
        private readonly ICommonRepository<Customer> _customerRepository;
        private readonly IMemoryCache _productsCache;
        private readonly IMapper _mapper;

        public HomeController(ICommonRepository<Product> productRepository, ICommonRepository<Category> categoryRepository, ICommonRepository<Customer> customerRepository, IMemoryCache productsCache, IMapper mapper)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
            _customerRepository = customerRepository;
            _productsCache = productsCache;
            _mapper = mapper;
        }

        public async Task<IActionResult> CategoryWiseProducts(int id,int page = 1, int pageSize = 8)
        {
            ViewBag.PageTitle = "Category wise prodcuts List";
            IEnumerable<ProductDto> cachedProducts;
            
            if(_productsCache.TryGetValue("ProductsList", out cachedProducts))
            {
                return View(cachedProducts);
            }
            MemoryCacheEntryOptions cacheOptions = new()
            {
                AbsoluteExpiration = DateTimeOffset.UtcNow.AddMinutes(1),
                SlidingExpiration = new TimeSpan(0, 0, 10)
            };

            var category = await _categoryRepository.GetDetailsAsync(id);

            var products = _mapper.Map<IEnumerable<ProductDto>>(await _productRepository.GetAllAsync()).Where(p => p.ShoeType.ToLower() == category.CategoryName.ToLower());
            if(products.Count() == 0 || products == null)
            {
                ViewBag.Message = "No products found for the searched category";
            }
            var query = products.AsQueryable();

            var totalCount = query.Count();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            query = query.Skip((page - 1) * pageSize).Take(pageSize);

            products = products.OrderBy(product => product.ProductId)
                   .Skip((page - 1) * pageSize)
                   .Take(pageSize).ToList();

            Pagination result = new Pagination
            {
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page,
                PageSize = pageSize,
                Product = products
            };

            _productsCache.Set("ProductsList", result, cacheOptions);

            return View("Index",result);
        }

        public async Task<IActionResult> Index(int page = 1, int pageSize = 8)
        {
            ViewBag.PageTitle = "Welcome To Bosch Prodcuts List!";
            IEnumerable<ProductDto> cachedProducts;

            if (_productsCache.TryGetValue("ProductsList", out cachedProducts))
            {
                return View(cachedProducts);
            }
            MemoryCacheEntryOptions cacheOptions = new()
            {
                AbsoluteExpiration = DateTimeOffset.UtcNow.AddMinutes(1),
                SlidingExpiration = new TimeSpan(0, 0, 10)
            };

            var products = _mapper.Map<IEnumerable<ProductDto>>(await _productRepository.GetAllAsync());

            var query = products.AsQueryable();

            var totalCount = query.Count();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            query = query.Skip((page - 1) * pageSize).Take(pageSize);

            products = products.OrderBy(product => product.ProductId)
                   .Skip((page - 1) * pageSize)
                   .Take(pageSize).ToList();

            Pagination result = new Pagination
            {
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page,
                PageSize = pageSize,
                Product = products
            };

            _productsCache.Set("ProductsList", result, cacheOptions);

            return View(result);
        }

        public async Task<IActionResult> Details(int productid)
        {
            ProductDto product = _mapper.Map<ProductDto>(await _productRepository.GetDetailsAsync(productid));
            TempData["NoBg"] = product.Picture.Replace(".jpg","-removebg-preview.png");
            product.Quantity = 1;
            ViewBag.PageTitle = $"Details Of {product.ProductName}";
            TempData["PayableAmount"] = JsonConvert.SerializeObject(product.UnitPrice - (product.UnitPrice * product.Discount) / 100);
            return View(product);
        }      
    }
}
