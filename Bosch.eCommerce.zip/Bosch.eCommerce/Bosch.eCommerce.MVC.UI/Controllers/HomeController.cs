using Bosch.eCommerce.MVC.UI.Models;
using Bosch.eCommerce.MVC.UI.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Bosch.eCommerce.MVC.UI.Controllers
{ 
    [BoschController]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [BoschAction]
        public IActionResult Index()
        {
            HttpContext.Session.SetInt32("CustomerId", 1);
            //Cookie cookie = new Cookie();
            //cookie.Secure = true;
            //cookie.Expires = DateTime.Now.AddHours(4);
            HttpContext.Response.Cookies.Append("Company", "Bosch Pvt. Ltd.");
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
