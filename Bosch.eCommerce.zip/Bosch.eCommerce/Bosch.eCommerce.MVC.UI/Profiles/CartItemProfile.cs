﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerce.Models.DTOs.CartItemDtos;

namespace Bosch.eCommerce.MVC.UI.Profiles
{
    public class CartItemProfile:Profile
    {
        public CartItemProfile() 
        {
            CreateMap<InsertCartItemDto, CartItem>();
        }
    }
}
