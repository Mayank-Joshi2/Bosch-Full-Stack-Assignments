﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerce.MVC.UI.DTOs.CategoryDtos;

namespace Bosch.eCommerce.MVC.UI.Profiles
{
    public class CategoryProfile:Profile
    {
        public CategoryProfile() 
        {
            //Fetch Data to be displayes in view
            CreateMap<Category, CategoryDto>();
            //Insert/Update/Delete Operations
            CreateMap<InsertCategoryDto,Category>();
        }
    }
}
