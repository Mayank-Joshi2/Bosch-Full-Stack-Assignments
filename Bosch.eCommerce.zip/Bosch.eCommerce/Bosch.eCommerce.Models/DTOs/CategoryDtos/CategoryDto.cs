﻿namespace Bosch.eCommerce.MVC.UI.DTOs.CategoryDtos
{
    public class CategoryDto
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}
