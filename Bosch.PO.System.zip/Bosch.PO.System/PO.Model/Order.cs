﻿namespace PO.Model
{
    public class Order
    {
        public int OrderAmount { get; set; }
        public DateTime OrderDate { get; set; }
        public string? OrderDescription { get; set; }
        public int OrderId { get; set; }
        = 0;

    }
}
