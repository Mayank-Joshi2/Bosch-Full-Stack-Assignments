﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PO.Model
{
    public class Product
    {

        public string? Seller { get; set; }
        public string? ProductName { get; set; }    
        public string? ProductDescription { get; set; }
        public int ProductId { get; set; }
        = 0;
        public string ProductType { get; set; }
    }
}
