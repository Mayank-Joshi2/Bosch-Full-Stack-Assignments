﻿using PO.Model;

namespace BoschSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer c1 = new Customer() { 
                Id = 1,
                Name = "Test",
                Address =  "India",
                Phone = "+91",
                Email = "test@test.com"
            };

            Product p1 = new Product()
            {
                ProductId = 1,
                ProductName = "Product1",
                ProductDescription = "Product",
                Seller = "Amazon",
                ProductType = "food"
            };

            Order o1 = new Order()
            {
                OrderId = 1,
                OrderAmount = 500,
                OrderDate = DateTime.Now,
                OrderDescription = "test",
            };
        }
    }
}
